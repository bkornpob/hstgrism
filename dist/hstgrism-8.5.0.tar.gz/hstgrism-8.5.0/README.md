# HSTGRISM

Webpage: https://bkornpob.github.io/hstgrism/

## 8.5.0
- contamination.py: introducing 'configuration'
- wfc3uvisg280.py
- sub2full.py

## 8.4.0
- contamination.py
- grismapcorr.py added min and max wavelength columns to the tables in order to force the code performing nearest neighbour extrapolation.

## 8.3.0
- headersummary.py

## 8.2.0
WFC3IRG141 is introduced.

## 8.1.0
ObjectMask is introduced.